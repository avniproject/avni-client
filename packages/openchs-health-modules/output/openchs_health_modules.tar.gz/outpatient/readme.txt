Simple clinical criteria to identify sepsis or pneumonia in neonates in the community needing treatment or referral.
https://www.ncbi.nlm.nih.gov/pubmed/15818294

Is Home-Based Diagnosis and Treatment of Neonatal Sepsis Feasible and Effective
http://www.nature.com/jp/journal/v25/n1s/full/7211273a.html

http://searchforhealth.ngo/research-articles/