var getDecisions = function (programEncounter, today) {
    return {enrolmentDecisions: [], encounterDecisions: []};
};

module.exports = {
    getDecisions: getDecisions
};